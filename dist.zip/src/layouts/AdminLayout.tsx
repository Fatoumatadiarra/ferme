import { useState } from 'react'
import { Outlet } from 'react-router-dom'
import { motion } from 'framer-motion'
import { AdminHeader, Sidebar } from '@/components/layout'
import { useIsMobile } from '@/hooks'
import { cn } from '@/utils'
import { pageTransition } from '@/utils/animations'

export default function AdminLayout() {
  const isMobile = useIsMobile()
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [collapsed, setCollapsed] = useState(false)

  return (
    <div className="min-h-svh bg-surface-muted dark:bg-surface-dark">
      <Sidebar
        isOpen={sidebarOpen || !isMobile}
        onClose={() => setSidebarOpen(false)}
        collapsed={!isMobile && collapsed}
        onToggleCollapse={() => setCollapsed(!collapsed)}
      />

      <div
        className={cn(
          'flex min-h-svh flex-col transition-all duration-300',
          !isMobile && (collapsed ? 'lg:pl-[72px]' : 'lg:pl-64'),
        )}
      >
        <AdminHeader onMenuClick={() => setSidebarOpen(true)} sidebarCollapsed={collapsed} />

        <motion.main className="flex-1 p-4 sm:p-6 lg:p-8" {...pageTransition}>
          <Outlet />
        </motion.main>

        <footer className="border-t border-gray-200 px-6 py-3 text-center text-xs text-gray-400 dark:border-gray-800">
          AgriFerme &mdash; Plateforme de gestion agricole intégrée
        </footer>
      </div>
    </div>
  )
}
