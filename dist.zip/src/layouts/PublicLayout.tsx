import { Outlet } from 'react-router-dom'
import { motion } from 'framer-motion'
import { PublicHeader, Footer } from '@/components/layout'
import { pageTransition } from '@/utils/animations'

export default function PublicLayout() {
  return (
    <div className="flex min-h-svh flex-col">
      <PublicHeader />
      <motion.main
        className="flex-1"
        {...pageTransition}
      >
        <Outlet />
      </motion.main>
      <Footer />
    </div>
  )
}
