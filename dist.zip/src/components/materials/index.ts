export * from './MaterialDetailModal'
