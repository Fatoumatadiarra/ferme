export { StockDetailModal } from './StockDetailModal'
