export { SaleDetailModal } from './SaleDetailModal'
