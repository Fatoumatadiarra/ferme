export { FishDetailModal } from './FishDetailModal'
