export { EmployeeDetailModal } from './EmployeeDetailModal'
