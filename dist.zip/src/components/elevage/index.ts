export * from './AnimalDetailModal'
