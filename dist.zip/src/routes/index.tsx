import { createBrowserRouter } from 'react-router-dom'
import PublicLayout from '@/layouts/PublicLayout'
import AdminLayout from '@/layouts/AdminLayout'
import LandingPage from '@/pages/public/LandingPage'
import AboutPage from '@/pages/public/AboutPage'
import ContactPage from '@/pages/public/ContactPage'
import LoginPage from '@/pages/public/LoginPage'
import RegisterPage from '@/pages/public/RegisterPage'
import DashboardPage from '@/pages/admin/DashboardPage'
import UsersPage from '@/pages/admin/UsersPage'
import EmployeesPage from '@/pages/admin/EmployeesPage'
import MaterialsPage from '@/pages/admin/MaterialsPage'
import MaraichagePage from '@/pages/admin/MaraichagePage'
import FruitsPage from '@/pages/admin/FruitsPage'
import AnimalsPage from '@/pages/admin/AnimalsPage'
import PoultryPage from '@/pages/admin/PoultryPage'
import AquaculturePage from '@/pages/admin/AquaculturePage'
import StocksPage from '@/pages/admin/StocksPage'
import ClientsPage from '@/pages/admin/ClientsPage'
import SalesPage from '@/pages/admin/SalesPage'
import ExpensesPage from '@/pages/admin/ExpensesPage'
import StatisticsPage from '@/pages/admin/StatisticsPage'
import SettingsPage from '@/pages/admin/SettingsPage'


export const router = createBrowserRouter([
  {
    path: '/',
    element: <PublicLayout />,
    children: [
      { index: true, element: <LandingPage /> },
      { path: 'a-propos', element: <AboutPage /> },
      { path: 'contact', element: <ContactPage /> },
      { path: 'connexion', element: <LoginPage /> },
      { path: 'inscription', element: <RegisterPage /> },
    ],
  },
  {
    path: '/admin',
    element: <AdminLayout />,
    children: [
      { index: true, element: <DashboardPage /> },
      {
        path: 'utilisateurs',
        element: <UsersPage />,
      },
      {
        path: 'employes',
        element: <EmployeesPage />,
      },
      {
        path: 'maraichage',
        element: <MaraichagePage />,
      },
      {
        path: 'fruits',
        element: <FruitsPage />,
      },
      {
        path: 'elevage',
        element: <AnimalsPage />,
      },
      {
        path: 'aviculture',
        element: <PoultryPage />,
      },
      {
        path: 'aquaculture',
        element: <AquaculturePage />,
      },
      {
        path: 'materiels',
        element: <MaterialsPage />,
      },
      {
        path: 'stocks',
        element: <StocksPage />,
      },
      {
        path: 'clients',
        element: <ClientsPage />,
      },
      {
        path: 'ventes',
        element: <SalesPage />,
      },
      {
        path: 'depenses',
        element: <ExpensesPage />,
      },
      {
        path: 'statistiques',
        element: <StatisticsPage />,
      },
      {
        path: 'parametres',
        element: <SettingsPage />,
      },
    ],
  },
])
